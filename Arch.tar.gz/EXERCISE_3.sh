SERVER_NAME=$(hostname)
echo " you are running this script on ${SERVER_NAME}."
