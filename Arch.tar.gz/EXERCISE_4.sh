#!/bin/bash
file1=$(cd /etc | grep shadow)

if(f1=$file1)
then
    echo "Shadow passwords are enabled."
fi

[[ -w /etc/shadow ]] && echo "You have permissions to edit /etc/shadow." || echo "You do NOT have permissions to edit /etc/shadow."