#!/bin/bash
VAR=$(echo "Shell Scripting is Fun!")
echo ${VAR}
