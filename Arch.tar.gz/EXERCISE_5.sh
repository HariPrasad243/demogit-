#!/bin/bash
for ANIMAL in bear pig dog cat sheep
do
	echo ${ANIMAL}
done
